#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <windows.h>
#include <fstream>
#include <cstring>
#include <map>
#include <unordered_set>
using namespace std;



/* 0    <constant>
 * 1    int
 * 2    if
 * 3    else
 * 4    then
 * 5    while
 * 6    do
 * 7    begin
 * 8    end
 * 9    +
 * 10   *
 * 11   =
 * 12   (
 * 13   )
 * 14   <
 * 15   >
 * 16   !=
 * 17   >=
 * 18   <=
 * 19   ==
 * 20   ,
 * 21   ;
 * 22   <Identifiers>
 * */

// ���������Ž������µĸ�ֵ
#define ID_IDENTIFIER 22

map<string, int> table;  // �����ǩӳ��ĺ���
map<int, string> _table;
// ȷ��������
unordered_set<string> identifier_table;
unordered_set<string> constants_table;
string variable_statement[] = { "int" };
string keywords[] = { "if","else","then","while","do","begin","end"};
string mathOperator[] = { "+","*","=","(",")" };
string seperator[] = { ";","," };
string logicalOperator[] = { "==","<=",">=","<",">","!=" };
const int N = 50010;
// ʹ��һ���ṹ�屣��word��value type  �����ڵ���
struct word {
    string value;
    int type;
    int line;
};

word next_word;

string letters[N];      // ��ŵ��ʵ�buffer
int file_length;        // �ļ���������
int cur;                // ָ��ǰ��ĸλ�õ�ָ��
int cur_line = 1;       // ��ǰָ�����ڵ�����
string cur_word;        // ��ǰָ������ʾ�ĵ���
bool have_error = false;// ��������


// ������ȷ����ǩ��Ž�ӳ���map��
void init() {
    table["number"] = 0;
    int idx = 1;
    for (auto x : variable_statement) {
        table[x] = idx++;
    }

    for (auto x : keywords) {
        table[x] = idx++;
    }
    
    for (auto x : mathOperator) {
        table[x] = idx++;
    }
    for (auto x : logicalOperator) {
        table[x] = idx++;
    }

    for (auto x : seperator) {
        table[x] = idx++;
    }
    table["identifier"] = 22;


    _table[0] = "number";
    _table[1] = "����˵��";
    for (int i = 2; i <= 8; ++i) {
        _table[i] = "keyword";
    }
    _table[9] = "mathOperator";
    _table[10] = "mathOperator";
    _table[11] = "mathOperator";
    _table[12] = "mathOperator";
    _table[13] = "mathOperator";
    for (int i = 14; i <= 17; ++i)_table[i] = "logicalOperator";
    for (int i = 18; i <= 21; ++i)_table[i] = "seperator";
    _table[22] = "identifier";
}



int is_reserved(string s) {
    return table[s];
}

int is_symbol(string s) {
    return table[s];
}

bool is_digit(string s) {
    if ("0" <= s && s <= "9")
        return true;
    return false;
}

bool is_letter(string s) {
    if ("a" <= s && s <= "z")
        return true;
    return false;
}



string concat_reserved(string s, int n) {
    int i = n + 1;
    while (is_digit(letters[i]) || is_letter(letters[i])) {
        s = (s + letters[i++]).c_str();
        if (is_reserved(s)) {
            cur = i;
            return s;
        }
    }
    cur = i;
    return s;
}

string concat_symbol(string s, int n) {
    int i = n + 1;
    string ss = letters[i];
    if (ss == ">" || ss == "=" || ss == "<" || ss == "!") {
        s = (s + letters[i++]).c_str();
    }
    cur = i;
    return s;
}

// ƴ�ӱ�ʶ��
string concat_identifier(string s, int n) {
    int i = n + 1;
    // �Ա�ʶ���ĵڶ����ַ������ж�
    if (!is_letter(letters[i])) {
        have_error = true;
        return s;
    }
    else {
        s = (s+letters[i++]).c_str();
    }
    while (is_digit(letters[i]) || is_letter(letters[i])) {
        s = (s + letters[i++]).c_str();
    }
    cur = i;
    return s;
}

string concat_digit(string s, int n) {
    int i = n + 1;
    while (is_digit(letters[i])) {
            s = (s + letters[i++]).c_str();
    }
    cur = i;
    return s;
}


int judge_char_type(string s) {
    if (s == "$") {
        return ID_IDENTIFIER; //��� $ ��ͷ˵������һ����ʶ��
    }
    if (is_letter(s))return 1;
    if (is_digit(s))return 2;
    if (s == ">" || s == "=" || s == "<" || s == "!")return 3;
    if (s == "+" || s == "*" || s == "=" ||
        s == "," || s == ";" || s == "(" || s == ")")return 4;
    return 0;
    
}


void scanner() {
    
    int ty;
    if (cur < file_length) {
        string s1, s2;
        s1 = letters[cur];
        while (letters[cur] == " " || letters[cur] == "\n" || letters[cur] == "\t") {
            // ����ǰ��ͷָ����ַ�����������ʱ������ö���һ��������
            if (letters[cur] == "\n")cur_line++;
            if (cur + 1 >= file_length)
                return;
            s1 = letters[++cur];
        }
        ty = judge_char_type(s1);
        switch (ty) {
        case ID_IDENTIFIER:
            s2 = concat_identifier(s1, cur);
            if (!have_error)identifier_table.insert(s2);
            next_word.value = s2;
            next_word.line = cur_line;
            next_word.type = ID_IDENTIFIER;
            break;
        case 1:  // ���������һ����ĸ��ʱ��
            s2 = concat_reserved(s1, cur); // Ĭ�Ͽ�ʼ��ȡ������
            if (is_reserved(s2)) {
                next_word.value = s2;
                next_word.line = cur_line;
                next_word.type = table[s2];
            }
            else {
                // ˵���ַ���S2���Ǳ������Ǿͳ���
                have_error = true;
            }
            break;
        case 2:  // ����ĵ�һ���ַ���һ������ ��ô���ǳ�����
            s2 = concat_digit(s1, cur);
            constants_table.insert(s2);
            next_word.value = s2;
            next_word.line = cur_line;
            next_word.type = table["number"];
            break;
        case 3:
            s2 = concat_symbol(s1, cur);
            
            next_word.value = s2;
            next_word.line = cur_line;
            next_word.type = table[s2];
            break;
        case 4: //  �ָ����ź� ��Ŀ������� * + =
            s2 = s1;
            next_word.value = s2;
            next_word.line = cur_line;
            next_word.type = table[s2];
            cur++;
            break;
        default:
            have_error = true;
            break;
        }
    }

}


int main() {
    // �������
    init();
    char ch;
    freopen("in.txt", "r", stdin);

    file_length = 0;
    // ������txt���뵽letter buffer��
    while (~scanf("%c", &ch)) {
        letters[file_length++] = ch;
    }
    freopen("CON", "r", stdin);
    //
    cout << "File_length: " << file_length << endl;
    cur = 0;
    cur_line = 1;

    while (cur != file_length) {
        scanner();
       /* if (have_error) {
            cout << next_word.line << " have an error!!\n";
        }*/
        //have_error = false;
        cout <<"(" << _table[next_word.type] << "," << next_word.value << ")" << endl;
    }
    cout << "identifier table:";
    for (auto x:identifier_table) {
        cout << x<< " ";
    }
    cout << ";\n";
    cout << "constant table: ";
    for (auto x:constants_table) {
        cout << x<<" ";
    }
    cout << ";\n";
   
    system("pause");
    return 0;
}